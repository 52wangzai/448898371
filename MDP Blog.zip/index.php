<?php
$version='0.0.2'; // 当前版本
// 网站标题设置
$Site_title='MDP Blog 超简约的博客';
// 网站标题设置
require_once 'Parsedown.php';
$parser=new Parsedown();
$files=scandir('文章');
$list=array();
foreach($files as $file){
$modifiedTime=filemtime('文章/'.$file);
$md=explode('.md',$file);
$title=$md[0];
$time=date('Y-m-d H:i:s', $modifiedTime);
$list[]=array('title'=>$title,'time'=>$time);
}
if($_GET['md']){
$md=$_GET['md'];
$markdown=file_get_contents('文章/'.$md.'.md');
$html=$parser->text($markdown);
echo <<<EOF
<!DOCTYPE html>
<html>
<head>
<title>$Site_title — $md</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
<link rel="stylesheet" href="//jixiejidiguan.top/start/mdui/css/mdui.min.css"/>
<script src="//jixiejidiguan.top/start/mdui/js/mdui.min.js"></script>
</head>
<body class="mdui-appbar-with-toolbar">
<div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
<div class="mdui-toolbar">
<a href="javascript:;" class="mdui-typo-title">$Site_title</a>
<div class="mdui-toolbar-spacer"></div>
</div>
</div>
<div class="mdui-container-fluid">
<div class="mdui-m-t-3"></div>
<p class="mdui-typo">$html</p>
</div>
</body>
</html>
EOF;
}else{
$json=json_encode($list);
$data=json_decode($json, true);
echo <<<EOF
<!DOCTYPE html>
<html>
<head>
<title>$Site_title</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no"/>
<link rel="stylesheet" href="//jixiejidiguan.top/start/mdui/css/mdui.min.css"/>
<script src="//jixiejidiguan.top/start/mdui/js/mdui.min.js"></script>
</head>
<body class="mdui-appbar-with-toolbar">
<div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
<div class="mdui-toolbar">
<a href="javascript:;" class="mdui-typo-title">$Site_title</a>
<div class="mdui-toolbar-spacer"></div>
</div>
</div>
<div class="mdui-container-fluid">
<div class="mdui-m-t-3"></div>
EOF;
foreach($data as $item){
$title=$item['title'];
$time=$item['time'];
echo <<<EOF
<a class="mdui-grid-tile" href="?md=$title">
<div class="mdui-card mdui-card-primary">
<div class="mdui-text-left mdui-card-primary-title">$title</div>
<div class="mdui-text-right mdui-card-primary-subtitle">发布时间：$time</div>
</div><br>
</a>
EOF;
}
echo <<<EOF
</div>
</body>
</html>
EOF;
}